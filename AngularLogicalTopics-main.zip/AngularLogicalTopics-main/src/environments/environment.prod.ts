export const environment = {
  production: true,
  apiEndPoint: "https://akbarapi.funplanetresort.in/api/MyRequest/"
};
