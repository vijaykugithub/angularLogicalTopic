export const myConstant = {
  apiMethodName: {
    allRequest:'GetAllRequest',
    creatRequrets: '',
    update:''
  }
}
