import { TolltipTemplateDirective } from './tolltip-template.directive';

describe('TolltipTemplateDirective', () => {
  it('should create an instance', () => {
    const directive = new TolltipTemplateDirective();
    expect(directive).toBeTruthy();
  });
});
